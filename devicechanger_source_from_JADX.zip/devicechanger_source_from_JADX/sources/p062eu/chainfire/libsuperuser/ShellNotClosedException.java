package p062eu.chainfire.libsuperuser;

/* renamed from: eu.chainfire.libsuperuser.ShellNotClosedException */
public class ShellNotClosedException extends RuntimeException {
    public static final String EXCEPTION_NOT_CLOSED = "App did not close() interactive shell";

    public ShellNotClosedException() {
        super(EXCEPTION_NOT_CLOSED);
    }
}
