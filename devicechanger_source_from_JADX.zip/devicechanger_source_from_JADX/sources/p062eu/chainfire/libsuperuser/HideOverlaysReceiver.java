package p062eu.chainfire.libsuperuser;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* renamed from: eu.chainfire.libsuperuser.HideOverlaysReceiver */
public abstract class HideOverlaysReceiver extends BroadcastReceiver {
    public static final String ACTION_HIDE_OVERLAYS = "eu.chainfire.supersu.action.HIDE_OVERLAYS";
    public static final String CATEGORY_HIDE_OVERLAYS = "android.intent.category.INFO";
    public static final String EXTRA_HIDE_OVERLAYS = "eu.chainfire.supersu.extra.HIDE";

    public abstract void onHideOverlays(Context context, Intent intent, boolean z);

    public final void onReceive(Context context, Intent intent) {
        if (intent.hasExtra(EXTRA_HIDE_OVERLAYS)) {
            onHideOverlays(context, intent, intent.getBooleanExtra(EXTRA_HIDE_OVERLAYS, false));
        }
    }
}
