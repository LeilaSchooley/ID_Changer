package p062eu.chainfire.libsuperuser;

import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import com.google.android.exoplayer2.C1274C;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import p062eu.chainfire.libsuperuser.StreamGobbler.OnLineListener;

/* renamed from: eu.chainfire.libsuperuser.Shell */
public class Shell {
    protected static String[] availableTestCommands = {"echo -BOC-", "id"};

    /* renamed from: eu.chainfire.libsuperuser.Shell$Builder */
    public static class Builder {
        /* access modifiers changed from: private */
        public boolean autoHandler = true;
        /* access modifiers changed from: private */
        public List<Command> commands = new LinkedList();
        /* access modifiers changed from: private */
        public Map<String, String> environment = new HashMap();
        /* access modifiers changed from: private */
        public Handler handler = null;
        /* access modifiers changed from: private */
        public OnLineListener onSTDERRLineListener = null;
        /* access modifiers changed from: private */
        public OnLineListener onSTDOUTLineListener = null;
        /* access modifiers changed from: private */
        public String shell = "sh";
        /* access modifiers changed from: private */
        public boolean wantSTDERR = false;
        /* access modifiers changed from: private */
        public int watchdogTimeout = 0;

        public Builder setHandler(Handler handler2) {
            this.handler = handler2;
            return this;
        }

        public Builder setAutoHandler(boolean z) {
            this.autoHandler = z;
            return this;
        }

        public Builder setShell(String str) {
            this.shell = str;
            return this;
        }

        public Builder useSH() {
            return setShell("sh");
        }

        public Builder useSU() {
            return setShell("su");
        }

        public Builder setWantSTDERR(boolean z) {
            this.wantSTDERR = z;
            return this;
        }

        public Builder addEnvironment(String str, String str2) {
            this.environment.put(str, str2);
            return this;
        }

        public Builder addEnvironment(Map<String, String> map) {
            this.environment.putAll(map);
            return this;
        }

        public Builder addCommand(String str) {
            return addCommand(str, 0, (OnCommandResultListener) null);
        }

        public Builder addCommand(String str, int i, OnCommandResultListener onCommandResultListener) {
            return addCommand(new String[]{str}, i, onCommandResultListener);
        }

        public Builder addCommand(List<String> list) {
            return addCommand(list, 0, (OnCommandResultListener) null);
        }

        public Builder addCommand(List<String> list, int i, OnCommandResultListener onCommandResultListener) {
            return addCommand((String[]) list.toArray(new String[list.size()]), i, onCommandResultListener);
        }

        public Builder addCommand(String[] strArr) {
            return addCommand(strArr, 0, (OnCommandResultListener) null);
        }

        public Builder addCommand(String[] strArr, int i, OnCommandResultListener onCommandResultListener) {
            this.commands.add(new Command(strArr, i, onCommandResultListener, null));
            return this;
        }

        public Builder setOnSTDOUTLineListener(OnLineListener onLineListener) {
            this.onSTDOUTLineListener = onLineListener;
            return this;
        }

        public Builder setOnSTDERRLineListener(OnLineListener onLineListener) {
            this.onSTDERRLineListener = onLineListener;
            return this;
        }

        public Builder setWatchdogTimeout(int i) {
            this.watchdogTimeout = i;
            return this;
        }

        public Builder setMinimalLogging(boolean z) {
            Debug.setLogTypeEnabled(6, !z);
            return this;
        }

        public Interactive open() {
            return new Interactive(this, null);
        }

        public Interactive open(OnCommandResultListener onCommandResultListener) {
            return new Interactive(this, onCommandResultListener);
        }
    }

    /* renamed from: eu.chainfire.libsuperuser.Shell$Command */
    private static class Command {
        private static int commandCounter;
        /* access modifiers changed from: private */
        public final int code;
        /* access modifiers changed from: private */
        public final String[] commands;
        /* access modifiers changed from: private */
        public final String marker;
        /* access modifiers changed from: private */
        public final OnCommandLineListener onCommandLineListener;
        /* access modifiers changed from: private */
        public final OnCommandResultListener onCommandResultListener;

        public Command(String[] strArr, int i, OnCommandResultListener onCommandResultListener2, OnCommandLineListener onCommandLineListener2) {
            this.commands = strArr;
            this.code = i;
            this.onCommandResultListener = onCommandResultListener2;
            this.onCommandLineListener = onCommandLineListener2;
            StringBuilder sb = new StringBuilder();
            sb.append(UUID.randomUUID().toString());
            int i2 = commandCounter + 1;
            commandCounter = i2;
            sb.append(String.format("-%08x", new Object[]{Integer.valueOf(i2)}));
            this.marker = sb.toString();
        }
    }

    /* renamed from: eu.chainfire.libsuperuser.Shell$Interactive */
    public static class Interactive {
        private StreamGobbler STDERR;
        private DataOutputStream STDIN;
        private StreamGobbler STDOUT;
        private final boolean autoHandler;
        private volatile List<String> buffer;
        private final Object callbackSync;
        private volatile int callbacks;
        private volatile boolean closed;
        /* access modifiers changed from: private */
        public volatile Command command;
        private final List<Command> commands;
        private final Map<String, String> environment;
        private final Handler handler;
        private volatile boolean idle;
        private final Object idleSync;
        /* access modifiers changed from: private */
        public volatile int lastExitCode;
        /* access modifiers changed from: private */
        public volatile String lastMarkerSTDERR;
        /* access modifiers changed from: private */
        public volatile String lastMarkerSTDOUT;
        /* access modifiers changed from: private */
        public final OnLineListener onSTDERRLineListener;
        /* access modifiers changed from: private */
        public final OnLineListener onSTDOUTLineListener;
        private Process process;
        private volatile boolean running;
        /* access modifiers changed from: private */
        public final String shell;
        /* access modifiers changed from: private */
        public final boolean wantSTDERR;
        private ScheduledThreadPoolExecutor watchdog;
        private volatile int watchdogCount;
        /* access modifiers changed from: private */
        public int watchdogTimeout;

        private Interactive(final Builder builder, final OnCommandResultListener onCommandResultListener) {
            this.process = null;
            this.STDIN = null;
            this.STDOUT = null;
            this.STDERR = null;
            this.watchdog = null;
            this.running = false;
            this.idle = true;
            this.closed = true;
            this.callbacks = 0;
            this.idleSync = new Object();
            this.callbackSync = new Object();
            this.lastExitCode = 0;
            this.lastMarkerSTDOUT = null;
            this.lastMarkerSTDERR = null;
            this.command = null;
            this.buffer = null;
            this.autoHandler = builder.autoHandler;
            this.shell = builder.shell;
            this.wantSTDERR = builder.wantSTDERR;
            this.commands = builder.commands;
            this.environment = builder.environment;
            this.onSTDOUTLineListener = builder.onSTDOUTLineListener;
            this.onSTDERRLineListener = builder.onSTDERRLineListener;
            this.watchdogTimeout = builder.watchdogTimeout;
            if (Looper.myLooper() == null || builder.handler != null || !this.autoHandler) {
                this.handler = builder.handler;
            } else {
                this.handler = new Handler();
            }
            if (onCommandResultListener != null) {
                this.watchdogTimeout = 60;
                this.commands.add(0, new Command(Shell.availableTestCommands, 0, new OnCommandResultListener() {
                    public void onCommandResult(int i, int i2, List<String> list) {
                        if (i2 == 0 && !Shell.parseAvailableResult(list, C1423SU.isSU(Interactive.this.shell))) {
                            i2 = -4;
                        }
                        Interactive.this.watchdogTimeout = builder.watchdogTimeout;
                        onCommandResultListener.onCommandResult(0, i2, list);
                    }
                }, null));
            }
            if (!open() && onCommandResultListener != null) {
                onCommandResultListener.onCommandResult(0, -3, null);
            }
        }

        /* access modifiers changed from: protected */
        public void finalize() throws Throwable {
            if (this.closed || !Debug.getSanityChecksEnabledEffective()) {
                super.finalize();
            } else {
                Debug.log(ShellNotClosedException.EXCEPTION_NOT_CLOSED);
                throw new ShellNotClosedException();
            }
        }

        public void addCommand(String str) {
            addCommand(str, 0, (OnCommandResultListener) null);
        }

        public void addCommand(String str, int i, OnCommandResultListener onCommandResultListener) {
            addCommand(new String[]{str}, i, onCommandResultListener);
        }

        public void addCommand(String str, int i, OnCommandLineListener onCommandLineListener) {
            addCommand(new String[]{str}, i, onCommandLineListener);
        }

        public void addCommand(List<String> list) {
            addCommand(list, 0, (OnCommandResultListener) null);
        }

        public void addCommand(List<String> list, int i, OnCommandResultListener onCommandResultListener) {
            addCommand((String[]) list.toArray(new String[list.size()]), i, onCommandResultListener);
        }

        public void addCommand(List<String> list, int i, OnCommandLineListener onCommandLineListener) {
            addCommand((String[]) list.toArray(new String[list.size()]), i, onCommandLineListener);
        }

        public void addCommand(String[] strArr) {
            addCommand(strArr, 0, (OnCommandResultListener) null);
        }

        public synchronized void addCommand(String[] strArr, int i, OnCommandResultListener onCommandResultListener) {
            this.commands.add(new Command(strArr, i, onCommandResultListener, null));
            runNextCommand();
        }

        public synchronized void addCommand(String[] strArr, int i, OnCommandLineListener onCommandLineListener) {
            this.commands.add(new Command(strArr, i, null, onCommandLineListener));
            runNextCommand();
        }

        private void runNextCommand() {
            runNextCommand(true);
        }

        /* access modifiers changed from: private */
        public synchronized void handleWatchdog() {
            int i;
            if (this.watchdog != null) {
                if (this.watchdogTimeout != 0) {
                    if (!isRunning()) {
                        i = -2;
                        Debug.log(String.format("[%s%%] SHELL_DIED", new Object[]{this.shell.toUpperCase(Locale.ENGLISH)}));
                    } else {
                        int i2 = this.watchdogCount;
                        this.watchdogCount = i2 + 1;
                        if (i2 >= this.watchdogTimeout) {
                            i = -1;
                            Debug.log(String.format("[%s%%] WATCHDOG_EXIT", new Object[]{this.shell.toUpperCase(Locale.ENGLISH)}));
                        } else {
                            return;
                        }
                    }
                    postCallback(this.command, i, this.buffer);
                    this.command = null;
                    this.buffer = null;
                    this.idle = true;
                    this.watchdog.shutdown();
                    this.watchdog = null;
                    kill();
                }
            }
        }

        private void startWatchdog() {
            if (this.watchdogTimeout != 0) {
                this.watchdogCount = 0;
                this.watchdog = new ScheduledThreadPoolExecutor(1);
                this.watchdog.scheduleAtFixedRate(new Runnable() {
                    public void run() {
                        Interactive.this.handleWatchdog();
                    }
                }, 1, 1, TimeUnit.SECONDS);
            }
        }

        private void stopWatchdog() {
            if (this.watchdog != null) {
                this.watchdog.shutdownNow();
                this.watchdog = null;
            }
        }

        private void runNextCommand(boolean z) {
            String[] access$1300;
            boolean isRunning = isRunning();
            if (!isRunning) {
                this.idle = true;
            }
            if (isRunning && this.idle && this.commands.size() > 0) {
                Command command2 = (Command) this.commands.get(0);
                this.commands.remove(0);
                this.buffer = null;
                this.lastExitCode = 0;
                this.lastMarkerSTDOUT = null;
                this.lastMarkerSTDERR = null;
                if (command2.commands.length > 0) {
                    try {
                        if (command2.onCommandResultListener != null) {
                            this.buffer = Collections.synchronizedList(new ArrayList());
                        }
                        this.idle = false;
                        this.command = command2;
                        startWatchdog();
                        for (String str : command2.commands) {
                            Debug.logCommand(String.format("[%s+] %s", new Object[]{this.shell.toUpperCase(Locale.ENGLISH), str}));
                            DataOutputStream dataOutputStream = this.STDIN;
                            StringBuilder sb = new StringBuilder();
                            sb.append(str);
                            sb.append("\n");
                            dataOutputStream.write(sb.toString().getBytes(C1274C.UTF8_NAME));
                        }
                        DataOutputStream dataOutputStream2 = this.STDIN;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("echo ");
                        sb2.append(command2.marker);
                        sb2.append(" $?\n");
                        dataOutputStream2.write(sb2.toString().getBytes(C1274C.UTF8_NAME));
                        DataOutputStream dataOutputStream3 = this.STDIN;
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("echo ");
                        sb3.append(command2.marker);
                        sb3.append(" >&2\n");
                        dataOutputStream3.write(sb3.toString().getBytes(C1274C.UTF8_NAME));
                        this.STDIN.flush();
                    } catch (IOException unused) {
                    }
                } else {
                    runNextCommand(false);
                }
            } else if (!isRunning) {
                while (this.commands.size() > 0) {
                    postCallback((Command) this.commands.remove(0), -2, null);
                }
            }
            if (this.idle && z) {
                synchronized (this.idleSync) {
                    this.idleSync.notifyAll();
                }
            }
        }

        /* access modifiers changed from: private */
        public synchronized void processMarker() {
            if (this.command.marker.equals(this.lastMarkerSTDOUT) && this.command.marker.equals(this.lastMarkerSTDERR)) {
                postCallback(this.command, this.lastExitCode, this.buffer);
                stopWatchdog();
                this.command = null;
                this.buffer = null;
                this.idle = true;
                runNextCommand();
            }
        }

        /* access modifiers changed from: private */
        public synchronized void processLine(final String str, final OnLineListener onLineListener) {
            if (onLineListener != null) {
                if (this.handler != null) {
                    startCallback();
                    this.handler.post(new Runnable() {
                        public void run() {
                            try {
                                onLineListener.onLine(str);
                            } finally {
                                Interactive.this.endCallback();
                            }
                        }
                    });
                } else {
                    onLineListener.onLine(str);
                }
            }
        }

        /* access modifiers changed from: private */
        public synchronized void addBuffer(String str) {
            if (this.buffer != null) {
                this.buffer.add(str);
            }
        }

        private void startCallback() {
            synchronized (this.callbackSync) {
                this.callbacks++;
            }
        }

        private void postCallback(final Command command2, final int i, final List<String> list) {
            if (command2.onCommandResultListener != null || command2.onCommandLineListener != null) {
                if (this.handler == null) {
                    if (command2.onCommandResultListener != null) {
                        command2.onCommandResultListener.onCommandResult(command2.code, i, list);
                    }
                    if (command2.onCommandLineListener != null) {
                        command2.onCommandLineListener.onCommandResult(command2.code, i);
                    }
                    return;
                }
                startCallback();
                this.handler.post(new Runnable() {
                    public void run() {
                        try {
                            if (command2.onCommandResultListener != null) {
                                command2.onCommandResultListener.onCommandResult(command2.code, i, list);
                            }
                            if (command2.onCommandLineListener != null) {
                                command2.onCommandLineListener.onCommandResult(command2.code, i);
                            }
                        } finally {
                            Interactive.this.endCallback();
                        }
                    }
                });
            }
        }

        /* access modifiers changed from: private */
        public void endCallback() {
            synchronized (this.callbackSync) {
                this.callbacks--;
                if (this.callbacks == 0) {
                    this.callbackSync.notifyAll();
                }
            }
        }

        private synchronized boolean open() {
            Debug.log(String.format("[%s%%] START", new Object[]{this.shell.toUpperCase(Locale.ENGLISH)}));
            try {
                if (this.environment.size() == 0) {
                    this.process = Runtime.getRuntime().exec(this.shell);
                } else {
                    HashMap hashMap = new HashMap();
                    hashMap.putAll(System.getenv());
                    hashMap.putAll(this.environment);
                    String[] strArr = new String[hashMap.size()];
                    int i = 0;
                    for (Entry entry : hashMap.entrySet()) {
                        StringBuilder sb = new StringBuilder();
                        sb.append((String) entry.getKey());
                        sb.append("=");
                        sb.append((String) entry.getValue());
                        strArr[i] = sb.toString();
                        i++;
                    }
                    this.process = Runtime.getRuntime().exec(this.shell, strArr);
                }
                this.STDIN = new DataOutputStream(this.process.getOutputStream());
                StringBuilder sb2 = new StringBuilder();
                sb2.append(this.shell.toUpperCase(Locale.ENGLISH));
                sb2.append("-");
                this.STDOUT = new StreamGobbler(sb2.toString(), this.process.getInputStream(), (OnLineListener) new OnLineListener() {
                    /* JADX WARNING: Code restructure failed: missing block: B:23:0x008e, code lost:
                        return;
                     */
                    /* Code decompiled incorrectly, please refer to instructions dump. */
                    public void onLine(java.lang.String r6) {
                        /*
                            r5 = this;
                            eu.chainfire.libsuperuser.Shell$Interactive r0 = p062eu.chainfire.libsuperuser.Shell.Interactive.this
                            monitor-enter(r0)
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Command r1 = r1.command     // Catch:{ all -> 0x008f }
                            if (r1 != 0) goto L_0x000d
                            monitor-exit(r0)     // Catch:{ all -> 0x008f }
                            return
                        L_0x000d:
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Command r1 = r1.command     // Catch:{ all -> 0x008f }
                            java.lang.String r1 = r1.marker     // Catch:{ all -> 0x008f }
                            int r1 = r6.indexOf(r1)     // Catch:{ all -> 0x008f }
                            r2 = 0
                            if (r1 != 0) goto L_0x001f
                            goto L_0x002e
                        L_0x001f:
                            if (r1 <= 0) goto L_0x002b
                            r2 = 0
                            java.lang.String r2 = r6.substring(r2, r1)     // Catch:{ all -> 0x008f }
                            java.lang.String r6 = r6.substring(r1)     // Catch:{ all -> 0x008f }
                            goto L_0x002e
                        L_0x002b:
                            r4 = r2
                            r2 = r6
                            r6 = r4
                        L_0x002e:
                            if (r2 == 0) goto L_0x004f
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            r1.addBuffer(r2)     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Interactive r3 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.StreamGobbler$OnLineListener r3 = r3.onSTDOUTLineListener     // Catch:{ all -> 0x008f }
                            r1.processLine(r2, r3)     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Interactive r3 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Command r3 = r3.command     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$OnCommandLineListener r3 = r3.onCommandLineListener     // Catch:{ all -> 0x008f }
                            r1.processLine(r2, r3)     // Catch:{ all -> 0x008f }
                        L_0x004f:
                            if (r6 == 0) goto L_0x008d
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ Exception -> 0x0075 }
                            eu.chainfire.libsuperuser.Shell$Interactive r2 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ Exception -> 0x0075 }
                            eu.chainfire.libsuperuser.Shell$Command r2 = r2.command     // Catch:{ Exception -> 0x0075 }
                            java.lang.String r2 = r2.marker     // Catch:{ Exception -> 0x0075 }
                            int r2 = r2.length()     // Catch:{ Exception -> 0x0075 }
                            int r2 = r2 + 1
                            java.lang.String r6 = r6.substring(r2)     // Catch:{ Exception -> 0x0075 }
                            r2 = 10
                            java.lang.Integer r6 = java.lang.Integer.valueOf(r6, r2)     // Catch:{ Exception -> 0x0075 }
                            int r6 = r6.intValue()     // Catch:{ Exception -> 0x0075 }
                            r1.lastExitCode = r6     // Catch:{ Exception -> 0x0075 }
                            goto L_0x0079
                        L_0x0075:
                            r6 = move-exception
                            r6.printStackTrace()     // Catch:{ all -> 0x008f }
                        L_0x0079:
                            eu.chainfire.libsuperuser.Shell$Interactive r6 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Command r1 = r1.command     // Catch:{ all -> 0x008f }
                            java.lang.String r1 = r1.marker     // Catch:{ all -> 0x008f }
                            r6.lastMarkerSTDOUT = r1     // Catch:{ all -> 0x008f }
                            eu.chainfire.libsuperuser.Shell$Interactive r6 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x008f }
                            r6.processMarker()     // Catch:{ all -> 0x008f }
                        L_0x008d:
                            monitor-exit(r0)     // Catch:{ all -> 0x008f }
                            return
                        L_0x008f:
                            r6 = move-exception
                            monitor-exit(r0)     // Catch:{ all -> 0x008f }
                            throw r6
                        */
                        throw new UnsupportedOperationException("Method not decompiled: p062eu.chainfire.libsuperuser.Shell.Interactive.C14205.onLine(java.lang.String):void");
                    }
                });
                StringBuilder sb3 = new StringBuilder();
                sb3.append(this.shell.toUpperCase(Locale.ENGLISH));
                sb3.append("*");
                this.STDERR = new StreamGobbler(sb3.toString(), this.process.getErrorStream(), (OnLineListener) new OnLineListener() {
                    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0057, code lost:
                        return;
                     */
                    /* Code decompiled incorrectly, please refer to instructions dump. */
                    public void onLine(java.lang.String r5) {
                        /*
                            r4 = this;
                            eu.chainfire.libsuperuser.Shell$Interactive r0 = p062eu.chainfire.libsuperuser.Shell.Interactive.this
                            monitor-enter(r0)
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x0058 }
                            eu.chainfire.libsuperuser.Shell$Command r1 = r1.command     // Catch:{ all -> 0x0058 }
                            if (r1 != 0) goto L_0x000d
                            monitor-exit(r0)     // Catch:{ all -> 0x0058 }
                            return
                        L_0x000d:
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x0058 }
                            eu.chainfire.libsuperuser.Shell$Command r1 = r1.command     // Catch:{ all -> 0x0058 }
                            java.lang.String r1 = r1.marker     // Catch:{ all -> 0x0058 }
                            int r1 = r5.indexOf(r1)     // Catch:{ all -> 0x0058 }
                            if (r1 != 0) goto L_0x001f
                            r5 = 0
                            goto L_0x0026
                        L_0x001f:
                            if (r1 <= 0) goto L_0x0026
                            r2 = 0
                            java.lang.String r5 = r5.substring(r2, r1)     // Catch:{ all -> 0x0058 }
                        L_0x0026:
                            if (r5 == 0) goto L_0x0040
                            eu.chainfire.libsuperuser.Shell$Interactive r2 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x0058 }
                            boolean r2 = r2.wantSTDERR     // Catch:{ all -> 0x0058 }
                            if (r2 == 0) goto L_0x0035
                            eu.chainfire.libsuperuser.Shell$Interactive r2 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x0058 }
                            r2.addBuffer(r5)     // Catch:{ all -> 0x0058 }
                        L_0x0035:
                            eu.chainfire.libsuperuser.Shell$Interactive r2 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x0058 }
                            eu.chainfire.libsuperuser.Shell$Interactive r3 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x0058 }
                            eu.chainfire.libsuperuser.StreamGobbler$OnLineListener r3 = r3.onSTDERRLineListener     // Catch:{ all -> 0x0058 }
                            r2.processLine(r5, r3)     // Catch:{ all -> 0x0058 }
                        L_0x0040:
                            if (r1 < 0) goto L_0x0056
                            eu.chainfire.libsuperuser.Shell$Interactive r5 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x0058 }
                            eu.chainfire.libsuperuser.Shell$Interactive r1 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x0058 }
                            eu.chainfire.libsuperuser.Shell$Command r1 = r1.command     // Catch:{ all -> 0x0058 }
                            java.lang.String r1 = r1.marker     // Catch:{ all -> 0x0058 }
                            r5.lastMarkerSTDERR = r1     // Catch:{ all -> 0x0058 }
                            eu.chainfire.libsuperuser.Shell$Interactive r5 = p062eu.chainfire.libsuperuser.Shell.Interactive.this     // Catch:{ all -> 0x0058 }
                            r5.processMarker()     // Catch:{ all -> 0x0058 }
                        L_0x0056:
                            monitor-exit(r0)     // Catch:{ all -> 0x0058 }
                            return
                        L_0x0058:
                            r5 = move-exception
                            monitor-exit(r0)     // Catch:{ all -> 0x0058 }
                            throw r5
                        */
                        throw new UnsupportedOperationException("Method not decompiled: p062eu.chainfire.libsuperuser.Shell.Interactive.C14216.onLine(java.lang.String):void");
                    }
                });
                this.STDOUT.start();
                this.STDERR.start();
                this.running = true;
                this.closed = false;
                runNextCommand();
            } catch (IOException unused) {
                return false;
            }
            return true;
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(4:31|32|33|35) */
        /* JADX WARNING: Code restructure failed: missing block: B:11:0x0018, code lost:
            if (p062eu.chainfire.libsuperuser.Debug.getSanityChecksEnabledEffective() == false) goto L_0x002d;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:13:0x001e, code lost:
            if (p062eu.chainfire.libsuperuser.Debug.onMainThread() == false) goto L_0x002d;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:14:0x0020, code lost:
            p062eu.chainfire.libsuperuser.Debug.log(p062eu.chainfire.libsuperuser.ShellOnMainThreadException.EXCEPTION_NOT_IDLE);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x002c, code lost:
            throw new p062eu.chainfire.libsuperuser.ShellOnMainThreadException(p062eu.chainfire.libsuperuser.ShellOnMainThreadException.EXCEPTION_NOT_IDLE);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x002d, code lost:
            if (r0 != false) goto L_0x0032;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x002f, code lost:
            waitForIdle();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:19:?, code lost:
            r5.STDIN.write("exit\n".getBytes(com.google.android.exoplayer2.C1274C.UTF8_NAME));
            r5.STDIN.flush();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:20:0x0045, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x0050, code lost:
            if (r0.getMessage().contains("EPIPE") == false) goto L_0x0052;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x005c, code lost:
            if (r0.getMessage().contains("Stream closed") != false) goto L_0x005e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x005f, code lost:
            throw r0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x0060, code lost:
            r5.process.waitFor();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:?, code lost:
            r5.STDIN.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:?, code lost:
            r5.STDOUT.join();
            r5.STDERR.join();
            stopWatchdog();
            r5.process.destroy();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x007c, code lost:
            p062eu.chainfire.libsuperuser.Debug.log(java.lang.String.format("[%s%%] END", new java.lang.Object[]{r5.shell.toUpperCase(java.util.Locale.ENGLISH)}));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:0x0091, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:9:0x0012, code lost:
            if (r0 != false) goto L_0x002d;
         */
        /* JADX WARNING: Missing exception handler attribute for start block: B:31:0x006a */
        /* JADX WARNING: Removed duplicated region for block: B:34:? A[ExcHandler: InterruptedException (unused java.lang.InterruptedException), SYNTHETIC, Splitter:B:21:0x0046] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void close() {
            /*
                r5 = this;
                boolean r0 = r5.isIdle()
                monitor-enter(r5)
                boolean r1 = r5.running     // Catch:{ all -> 0x0092 }
                if (r1 != 0) goto L_0x000b
                monitor-exit(r5)     // Catch:{ all -> 0x0092 }
                return
            L_0x000b:
                r1 = 0
                r5.running = r1     // Catch:{ all -> 0x0092 }
                r2 = 1
                r5.closed = r2     // Catch:{ all -> 0x0092 }
                monitor-exit(r5)     // Catch:{ all -> 0x0092 }
                if (r0 != 0) goto L_0x002d
                boolean r3 = p062eu.chainfire.libsuperuser.Debug.getSanityChecksEnabledEffective()
                if (r3 == 0) goto L_0x002d
                boolean r3 = p062eu.chainfire.libsuperuser.Debug.onMainThread()
                if (r3 == 0) goto L_0x002d
                java.lang.String r0 = "App attempted to wait for a non-idle shell to close on the main thread"
                p062eu.chainfire.libsuperuser.Debug.log(r0)
                eu.chainfire.libsuperuser.ShellOnMainThreadException r0 = new eu.chainfire.libsuperuser.ShellOnMainThreadException
                java.lang.String r1 = "App attempted to wait for a non-idle shell to close on the main thread"
                r0.<init>(r1)
                throw r0
            L_0x002d:
                if (r0 != 0) goto L_0x0032
                r5.waitForIdle()
            L_0x0032:
                java.io.DataOutputStream r0 = r5.STDIN     // Catch:{ IOException -> 0x0045 }
                java.lang.String r3 = "exit\n"
                java.lang.String r4 = "UTF-8"
                byte[] r3 = r3.getBytes(r4)     // Catch:{ IOException -> 0x0045 }
                r0.write(r3)     // Catch:{ IOException -> 0x0045 }
                java.io.DataOutputStream r0 = r5.STDIN     // Catch:{ IOException -> 0x0045 }
                r0.flush()     // Catch:{ IOException -> 0x0045 }
                goto L_0x0060
            L_0x0045:
                r0 = move-exception
                java.lang.String r3 = r0.getMessage()     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                java.lang.String r4 = "EPIPE"
                boolean r3 = r3.contains(r4)     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                if (r3 != 0) goto L_0x0060
                java.lang.String r3 = r0.getMessage()     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                java.lang.String r4 = "Stream closed"
                boolean r3 = r3.contains(r4)     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                if (r3 == 0) goto L_0x005f
                goto L_0x0060
            L_0x005f:
                throw r0     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
            L_0x0060:
                java.lang.Process r0 = r5.process     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                r0.waitFor()     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                java.io.DataOutputStream r0 = r5.STDIN     // Catch:{ IOException -> 0x006a }
                r0.close()     // Catch:{ IOException -> 0x006a }
            L_0x006a:
                eu.chainfire.libsuperuser.StreamGobbler r0 = r5.STDOUT     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                r0.join()     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                eu.chainfire.libsuperuser.StreamGobbler r0 = r5.STDERR     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                r0.join()     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                r5.stopWatchdog()     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                java.lang.Process r0 = r5.process     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
                r0.destroy()     // Catch:{ InterruptedException -> 0x007c, InterruptedException -> 0x007c }
            L_0x007c:
                java.lang.String r0 = "[%s%%] END"
                java.lang.Object[] r2 = new java.lang.Object[r2]
                java.lang.String r3 = r5.shell
                java.util.Locale r4 = java.util.Locale.ENGLISH
                java.lang.String r3 = r3.toUpperCase(r4)
                r2[r1] = r3
                java.lang.String r0 = java.lang.String.format(r0, r2)
                p062eu.chainfire.libsuperuser.Debug.log(r0)
                return
            L_0x0092:
                r0 = move-exception
                monitor-exit(r5)     // Catch:{ all -> 0x0092 }
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: p062eu.chainfire.libsuperuser.Shell.Interactive.close():void");
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(11:1|2|3|4|5|6|7|8|9|15|14) */
        /* JADX WARNING: Missing exception handler attribute for start block: B:6:0x000c */
        /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x0011 */
        /* JADX WARNING: Removed duplicated region for block: B:11:0x0016 A[SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public synchronized void kill() {
            /*
                r2 = this;
                monitor-enter(r2)
                r0 = 0
                r2.running = r0     // Catch:{ all -> 0x0021 }
                r0 = 1
                r2.closed = r0     // Catch:{ all -> 0x0021 }
                java.io.DataOutputStream r1 = r2.STDIN     // Catch:{ IOException -> 0x000c }
                r1.close()     // Catch:{ IOException -> 0x000c }
            L_0x000c:
                java.lang.Process r1 = r2.process     // Catch:{ Exception -> 0x0011 }
                r1.destroy()     // Catch:{ Exception -> 0x0011 }
            L_0x0011:
                r2.idle = r0     // Catch:{ all -> 0x0021 }
                java.lang.Object r0 = r2.idleSync     // Catch:{ all -> 0x0021 }
                monitor-enter(r0)     // Catch:{ all -> 0x0021 }
                java.lang.Object r1 = r2.idleSync     // Catch:{ all -> 0x001e }
                r1.notifyAll()     // Catch:{ all -> 0x001e }
                monitor-exit(r0)     // Catch:{ all -> 0x001e }
                monitor-exit(r2)
                return
            L_0x001e:
                r1 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x001e }
                throw r1     // Catch:{ all -> 0x0021 }
            L_0x0021:
                r0 = move-exception
                monitor-exit(r2)
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: p062eu.chainfire.libsuperuser.Shell.Interactive.kill():void");
        }

        public boolean isRunning() {
            if (this.process == null) {
                return false;
            }
            try {
                this.process.exitValue();
                return false;
            } catch (IllegalThreadStateException unused) {
                return true;
            }
        }

        public synchronized boolean isIdle() {
            if (!isRunning()) {
                this.idle = true;
                synchronized (this.idleSync) {
                    this.idleSync.notifyAll();
                }
            }
            return this.idle;
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(8:14|15|16|17|18|11|10|12) */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x0032, code lost:
            if (r3.handler == null) goto L_0x005f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x003a, code lost:
            if (r3.handler.getLooper() == null) goto L_0x005f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x0046, code lost:
            if (r3.handler.getLooper() == android.os.Looper.myLooper()) goto L_0x005f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:26:0x0048, code lost:
            r0 = r3.callbackSync;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x004a, code lost:
            monitor-enter(r0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x004d, code lost:
            if (r3.callbacks <= 0) goto L_0x0057;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:?, code lost:
            r3.callbackSync.wait();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:34:?, code lost:
            monitor-exit(r0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:0x0056, code lost:
            return false;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:36:0x0057, code lost:
            monitor-exit(r0);
         */
        /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
        /* JADX WARNING: Missing exception handler attribute for start block: B:16:0x002d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:33:0x0055 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean waitForIdle() {
            /*
                r3 = this;
                boolean r0 = p062eu.chainfire.libsuperuser.Debug.getSanityChecksEnabledEffective()
                if (r0 == 0) goto L_0x0019
                boolean r0 = p062eu.chainfire.libsuperuser.Debug.onMainThread()
                if (r0 == 0) goto L_0x0019
                java.lang.String r0 = "App attempted to wait for a shell to become idle on the main thread"
                p062eu.chainfire.libsuperuser.Debug.log(r0)
                eu.chainfire.libsuperuser.ShellOnMainThreadException r0 = new eu.chainfire.libsuperuser.ShellOnMainThreadException
                java.lang.String r1 = "App attempted to wait for a shell to become idle on the main thread"
                r0.<init>(r1)
                throw r0
            L_0x0019:
                boolean r0 = r3.isRunning()
                if (r0 == 0) goto L_0x005f
                java.lang.Object r0 = r3.idleSync
                monitor-enter(r0)
            L_0x0022:
                boolean r1 = r3.idle     // Catch:{ all -> 0x005c }
                r2 = 0
                if (r1 != 0) goto L_0x002f
                java.lang.Object r1 = r3.idleSync     // Catch:{ InterruptedException -> 0x002d }
                r1.wait()     // Catch:{ InterruptedException -> 0x002d }
                goto L_0x0022
            L_0x002d:
                monitor-exit(r0)     // Catch:{ all -> 0x005c }
                return r2
            L_0x002f:
                monitor-exit(r0)     // Catch:{ all -> 0x005c }
                android.os.Handler r0 = r3.handler
                if (r0 == 0) goto L_0x005f
                android.os.Handler r0 = r3.handler
                android.os.Looper r0 = r0.getLooper()
                if (r0 == 0) goto L_0x005f
                android.os.Handler r0 = r3.handler
                android.os.Looper r0 = r0.getLooper()
                android.os.Looper r1 = android.os.Looper.myLooper()
                if (r0 == r1) goto L_0x005f
                java.lang.Object r0 = r3.callbackSync
                monitor-enter(r0)
            L_0x004b:
                int r1 = r3.callbacks     // Catch:{ all -> 0x0059 }
                if (r1 <= 0) goto L_0x0057
                java.lang.Object r1 = r3.callbackSync     // Catch:{ InterruptedException -> 0x0055 }
                r1.wait()     // Catch:{ InterruptedException -> 0x0055 }
                goto L_0x004b
            L_0x0055:
                monitor-exit(r0)     // Catch:{ all -> 0x0059 }
                return r2
            L_0x0057:
                monitor-exit(r0)     // Catch:{ all -> 0x0059 }
                goto L_0x005f
            L_0x0059:
                r1 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x0059 }
                throw r1
            L_0x005c:
                r1 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x005c }
                throw r1
            L_0x005f:
                r0 = 1
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: p062eu.chainfire.libsuperuser.Shell.Interactive.waitForIdle():boolean");
        }

        public boolean hasHandler() {
            return this.handler != null;
        }
    }

    /* renamed from: eu.chainfire.libsuperuser.Shell$OnCommandLineListener */
    public interface OnCommandLineListener extends OnResult, OnLineListener {
        void onCommandResult(int i, int i2);
    }

    /* renamed from: eu.chainfire.libsuperuser.Shell$OnCommandResultListener */
    public interface OnCommandResultListener extends OnResult {
        void onCommandResult(int i, int i2, List<String> list);
    }

    /* renamed from: eu.chainfire.libsuperuser.Shell$OnResult */
    private interface OnResult {
        public static final int SHELL_DIED = -2;
        public static final int SHELL_EXEC_FAILED = -3;
        public static final int SHELL_RUNNING = 0;
        public static final int SHELL_WRONG_UID = -4;
        public static final int WATCHDOG_EXIT = -1;
    }

    /* renamed from: eu.chainfire.libsuperuser.Shell$SH */
    public static class C1422SH {
        public static List<String> run(String str) {
            return Shell.run("sh", new String[]{str}, null, false);
        }

        public static List<String> run(List<String> list) {
            return Shell.run("sh", (String[]) list.toArray(new String[list.size()]), null, false);
        }

        public static List<String> run(String[] strArr) {
            return Shell.run("sh", strArr, null, false);
        }
    }

    /* renamed from: eu.chainfire.libsuperuser.Shell$SU */
    public static class C1423SU {
        private static Boolean isSELinuxEnforcing;
        private static String[] suVersion = {null, null};

        public static List<String> run(String str) {
            return Shell.run("su", new String[]{str}, null, false);
        }

        public static List<String> run(List<String> list) {
            return Shell.run("su", (String[]) list.toArray(new String[list.size()]), null, false);
        }

        public static List<String> run(String[] strArr) {
            return Shell.run("su", strArr, null, false);
        }

        public static boolean available() {
            return Shell.parseAvailableResult(run(Shell.availableTestCommands), true);
        }

        public static synchronized String version(boolean z) {
            String str;
            String str2;
            synchronized (C1423SU.class) {
                char c = !z;
                if (suVersion[c] == null) {
                    List run = Shell.run(z ? "su -V" : "su -v", new String[]{"exit"}, null, false);
                    if (run != null) {
                        Iterator it = run.iterator();
                        while (true) {
                            if (!it.hasNext()) {
                                break;
                            }
                            str2 = (String) it.next();
                            if (!z) {
                                if (str2.trim().equals("")) {
                                }
                                break;
                            }
                            try {
                                if (Integer.parseInt(str2) <= 0) {
                                }
                                break;
                                break;
                            } catch (NumberFormatException unused) {
                                continue;
                            }
                        }
                    }
                    str2 = null;
                    break;
                    suVersion[c] = str2;
                    break;
                }
                str = suVersion[c];
            }
            return str;
        }

        public static boolean isSU(String str) {
            int indexOf = str.indexOf(32);
            if (indexOf >= 0) {
                str = str.substring(0, indexOf);
            }
            int lastIndexOf = str.lastIndexOf(47);
            if (lastIndexOf >= 0) {
                str = str.substring(lastIndexOf + 1);
            }
            return str.equals("su");
        }

        public static String shell(int i, String str) {
            String str2 = "su";
            if (str != null && isSELinuxEnforcing()) {
                String version = version(false);
                String version2 = version(true);
                if (version != null && version2 != null && version.endsWith("SUPERSU") && Integer.valueOf(version2).intValue() >= 190) {
                    str2 = String.format(Locale.ENGLISH, "%s --context %s", new Object[]{str2, str});
                }
            }
            if (i <= 0) {
                return str2;
            }
            return String.format(Locale.ENGLISH, "%s %d", new Object[]{str2, Integer.valueOf(i)});
        }

        public static String shellMountMaster() {
            return VERSION.SDK_INT >= 17 ? "su --mount-master" : "su";
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(7:28|29|30|31|32|(1:34)(1:35)|36) */
        /* JADX WARNING: Missing exception handler attribute for start block: B:31:0x005a */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x0060  */
        /* JADX WARNING: Removed duplicated region for block: B:35:0x0061  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public static synchronized boolean isSELinuxEnforcing() {
            /*
                java.lang.Class<eu.chainfire.libsuperuser.Shell$SU> r0 = p062eu.chainfire.libsuperuser.Shell.C1423SU.class
                monitor-enter(r0)
                java.lang.Boolean r1 = isSELinuxEnforcing     // Catch:{ all -> 0x0076 }
                if (r1 != 0) goto L_0x006e
                r1 = 0
                int r2 = android.os.Build.VERSION.SDK_INT     // Catch:{ all -> 0x0076 }
                r3 = 17
                r4 = 0
                if (r2 < r3) goto L_0x0066
                java.io.File r2 = new java.io.File     // Catch:{ all -> 0x0076 }
                java.lang.String r3 = "/sys/fs/selinux/enforce"
                r2.<init>(r3)     // Catch:{ all -> 0x0076 }
                boolean r2 = r2.exists()     // Catch:{ all -> 0x0076 }
                r3 = 1
                if (r2 == 0) goto L_0x003d
                java.io.FileInputStream r2 = new java.io.FileInputStream     // Catch:{ Exception -> 0x003d }
                java.lang.String r5 = "/sys/fs/selinux/enforce"
                r2.<init>(r5)     // Catch:{ Exception -> 0x003d }
                int r5 = r2.read()     // Catch:{ all -> 0x0038 }
                r6 = 49
                if (r5 != r6) goto L_0x002e
                r5 = 1
                goto L_0x002f
            L_0x002e:
                r5 = 0
            L_0x002f:
                java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)     // Catch:{ all -> 0x0038 }
                r2.close()     // Catch:{ Exception -> 0x0036 }
            L_0x0036:
                r1 = r5
                goto L_0x003d
            L_0x0038:
                r5 = move-exception
                r2.close()     // Catch:{ Exception -> 0x003d }
                throw r5     // Catch:{ Exception -> 0x003d }
            L_0x003d:
                if (r1 != 0) goto L_0x0066
                java.lang.String r1 = "android.os.SELinux"
                java.lang.Class r1 = java.lang.Class.forName(r1)     // Catch:{ Exception -> 0x005a }
                java.lang.String r2 = "isSELinuxEnforced"
                java.lang.Class[] r5 = new java.lang.Class[r4]     // Catch:{ Exception -> 0x005a }
                java.lang.reflect.Method r2 = r1.getMethod(r2, r5)     // Catch:{ Exception -> 0x005a }
                java.lang.Object r1 = r1.newInstance()     // Catch:{ Exception -> 0x005a }
                java.lang.Object[] r5 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x005a }
                java.lang.Object r1 = r2.invoke(r1, r5)     // Catch:{ Exception -> 0x005a }
                java.lang.Boolean r1 = (java.lang.Boolean) r1     // Catch:{ Exception -> 0x005a }
                goto L_0x0066
            L_0x005a:
                int r1 = android.os.Build.VERSION.SDK_INT     // Catch:{ all -> 0x0076 }
                r2 = 19
                if (r1 < r2) goto L_0x0061
                goto L_0x0062
            L_0x0061:
                r3 = 0
            L_0x0062:
                java.lang.Boolean r1 = java.lang.Boolean.valueOf(r3)     // Catch:{ all -> 0x0076 }
            L_0x0066:
                if (r1 != 0) goto L_0x006c
                java.lang.Boolean r1 = java.lang.Boolean.valueOf(r4)     // Catch:{ all -> 0x0076 }
            L_0x006c:
                isSELinuxEnforcing = r1     // Catch:{ all -> 0x0076 }
            L_0x006e:
                java.lang.Boolean r1 = isSELinuxEnforcing     // Catch:{ all -> 0x0076 }
                boolean r1 = r1.booleanValue()     // Catch:{ all -> 0x0076 }
                monitor-exit(r0)
                return r1
            L_0x0076:
                r1 = move-exception
                monitor-exit(r0)
                throw r1
            */
            throw new UnsupportedOperationException("Method not decompiled: p062eu.chainfire.libsuperuser.Shell.C1423SU.isSELinuxEnforcing():boolean");
        }

        public static synchronized void clearCachedResults() {
            synchronized (C1423SU.class) {
                isSELinuxEnforcing = null;
                suVersion[0] = null;
                suVersion[1] = null;
            }
        }
    }

    @Deprecated
    public static List<String> run(String str, String[] strArr, boolean z) {
        return run(str, strArr, null, z);
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(18:6|(7:8|9|(3:11|(2:13|51)(1:52)|14)|50|15|(2:18|16)|53)|19|(1:21)(1:22)|23|24|25|(1:27)|54|28|37|38|39|40|41|(1:46)|47|49) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:40:0x015a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.util.List<java.lang.String> run(java.lang.String r12, java.lang.String[] r13, java.lang.String[] r14, boolean r15) {
        /*
            java.util.Locale r0 = java.util.Locale.ENGLISH
            java.lang.String r0 = r12.toUpperCase(r0)
            boolean r1 = p062eu.chainfire.libsuperuser.Debug.getSanityChecksEnabledEffective()
            if (r1 == 0) goto L_0x001f
            boolean r1 = p062eu.chainfire.libsuperuser.Debug.onMainThread()
            if (r1 == 0) goto L_0x001f
            java.lang.String r12 = "App attempted to run a shell command from the main thread"
            p062eu.chainfire.libsuperuser.Debug.log(r12)
            eu.chainfire.libsuperuser.ShellOnMainThreadException r12 = new eu.chainfire.libsuperuser.ShellOnMainThreadException
            java.lang.String r13 = "App attempted to run a shell command from the main thread"
            r12.<init>(r13)
            throw r12
        L_0x001f:
            java.lang.String r1 = "[%s%%] START"
            r2 = 1
            java.lang.Object[] r3 = new java.lang.Object[r2]
            r4 = 0
            r3[r4] = r0
            java.lang.String r1 = java.lang.String.format(r1, r3)
            p062eu.chainfire.libsuperuser.Debug.logCommand(r1)
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.List r1 = java.util.Collections.synchronizedList(r1)
            r3 = 0
            if (r14 == 0) goto L_0x00a4
            java.util.HashMap r5 = new java.util.HashMap     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r5.<init>()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.util.Map r6 = java.lang.System.getenv()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r5.putAll(r6)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            int r6 = r14.length     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r7 = 0
        L_0x0048:
            if (r7 >= r6) goto L_0x0064
            r8 = r14[r7]     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r9 = "="
            int r9 = r8.indexOf(r9)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            if (r9 < 0) goto L_0x0061
            java.lang.String r10 = r8.substring(r4, r9)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            int r9 = r9 + 1
            java.lang.String r8 = r8.substring(r9)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r5.put(r10, r8)     // Catch:{ IOException | InterruptedException -> 0x0173 }
        L_0x0061:
            int r7 = r7 + 1
            goto L_0x0048
        L_0x0064:
            int r14 = r5.size()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String[] r14 = new java.lang.String[r14]     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.util.Set r5 = r5.entrySet()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.util.Iterator r5 = r5.iterator()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r6 = 0
        L_0x0073:
            boolean r7 = r5.hasNext()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            if (r7 == 0) goto L_0x00a4
            java.lang.Object r7 = r5.next()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.util.Map$Entry r7 = (java.util.Map.Entry) r7     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r8.<init>()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.Object r9 = r7.getKey()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r9 = (java.lang.String) r9     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r8.append(r9)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r9 = "="
            r8.append(r9)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.Object r7 = r7.getValue()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r7 = (java.lang.String) r7     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r8.append(r7)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r7 = r8.toString()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r14[r6] = r7     // Catch:{ IOException | InterruptedException -> 0x0173 }
            int r6 = r6 + 1
            goto L_0x0073
        L_0x00a4:
            java.lang.Runtime r5 = java.lang.Runtime.getRuntime()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.Process r14 = r5.exec(r12, r14)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.io.DataOutputStream r5 = new java.io.DataOutputStream     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.io.OutputStream r6 = r14.getOutputStream()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r5.<init>(r6)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            eu.chainfire.libsuperuser.StreamGobbler r6 = new eu.chainfire.libsuperuser.StreamGobbler     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r7.<init>()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r7.append(r0)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r8 = "-"
            r7.append(r8)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r7 = r7.toString()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.io.InputStream r8 = r14.getInputStream()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r6.<init>(r7, r8, r1)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            eu.chainfire.libsuperuser.StreamGobbler r7 = new eu.chainfire.libsuperuser.StreamGobbler     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r8.<init>()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r8.append(r0)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r9 = "*"
            r8.append(r9)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r8 = r8.toString()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.io.InputStream r9 = r14.getErrorStream()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            if (r15 == 0) goto L_0x00ea
            r15 = r1
            goto L_0x00eb
        L_0x00ea:
            r15 = r3
        L_0x00eb:
            r7.<init>(r8, r9, r15)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r6.start()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r7.start()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            int r15 = r13.length     // Catch:{ IOException -> 0x0139 }
            r8 = 0
        L_0x00f6:
            if (r8 >= r15) goto L_0x012a
            r9 = r13[r8]     // Catch:{ IOException -> 0x0139 }
            java.lang.String r10 = "[%s+] %s"
            r11 = 2
            java.lang.Object[] r11 = new java.lang.Object[r11]     // Catch:{ IOException -> 0x0139 }
            r11[r4] = r0     // Catch:{ IOException -> 0x0139 }
            r11[r2] = r9     // Catch:{ IOException -> 0x0139 }
            java.lang.String r10 = java.lang.String.format(r10, r11)     // Catch:{ IOException -> 0x0139 }
            p062eu.chainfire.libsuperuser.Debug.logCommand(r10)     // Catch:{ IOException -> 0x0139 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x0139 }
            r10.<init>()     // Catch:{ IOException -> 0x0139 }
            r10.append(r9)     // Catch:{ IOException -> 0x0139 }
            java.lang.String r9 = "\n"
            r10.append(r9)     // Catch:{ IOException -> 0x0139 }
            java.lang.String r9 = r10.toString()     // Catch:{ IOException -> 0x0139 }
            java.lang.String r10 = "UTF-8"
            byte[] r9 = r9.getBytes(r10)     // Catch:{ IOException -> 0x0139 }
            r5.write(r9)     // Catch:{ IOException -> 0x0139 }
            r5.flush()     // Catch:{ IOException -> 0x0139 }
            int r8 = r8 + 1
            goto L_0x00f6
        L_0x012a:
            java.lang.String r13 = "exit\n"
            java.lang.String r15 = "UTF-8"
            byte[] r13 = r13.getBytes(r15)     // Catch:{ IOException -> 0x0139 }
            r5.write(r13)     // Catch:{ IOException -> 0x0139 }
            r5.flush()     // Catch:{ IOException -> 0x0139 }
            goto L_0x0154
        L_0x0139:
            r13 = move-exception
            java.lang.String r15 = r13.getMessage()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r0 = "EPIPE"
            boolean r15 = r15.contains(r0)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            if (r15 != 0) goto L_0x0154
            java.lang.String r15 = r13.getMessage()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            java.lang.String r0 = "Stream closed"
            boolean r15 = r15.contains(r0)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            if (r15 == 0) goto L_0x0153
            goto L_0x0154
        L_0x0153:
            throw r13     // Catch:{ IOException | InterruptedException -> 0x0173 }
        L_0x0154:
            r14.waitFor()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r5.close()     // Catch:{ IOException -> 0x015a }
        L_0x015a:
            r6.join()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r7.join()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r14.destroy()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            boolean r13 = p062eu.chainfire.libsuperuser.Shell.C1423SU.isSU(r12)     // Catch:{ IOException | InterruptedException -> 0x0173 }
            if (r13 == 0) goto L_0x0172
            int r13 = r14.exitValue()     // Catch:{ IOException | InterruptedException -> 0x0173 }
            r14 = 255(0xff, float:3.57E-43)
            if (r13 != r14) goto L_0x0172
            goto L_0x0173
        L_0x0172:
            r3 = r1
        L_0x0173:
            java.lang.String r13 = "[%s%%] END"
            java.lang.Object[] r14 = new java.lang.Object[r2]
            java.util.Locale r15 = java.util.Locale.ENGLISH
            java.lang.String r12 = r12.toUpperCase(r15)
            r14[r4] = r12
            java.lang.String r12 = java.lang.String.format(r13, r14)
            p062eu.chainfire.libsuperuser.Debug.logCommand(r12)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p062eu.chainfire.libsuperuser.Shell.run(java.lang.String, java.lang.String[], java.lang.String[], boolean):java.util.List");
    }

    protected static boolean parseAvailableResult(List<String> list, boolean z) {
        boolean z2 = false;
        if (list == null) {
            return false;
        }
        boolean z3 = false;
        for (String str : list) {
            if (str.contains("uid=")) {
                if (!z || str.contains("uid=0")) {
                    z2 = true;
                }
                return z2;
            } else if (str.contains("-BOC-")) {
                z3 = true;
            }
        }
        return z3;
    }
}
