package p062eu.chainfire.libsuperuser;

import android.os.Build.VERSION;
import java.util.List;
import java.util.Locale;
import p062eu.chainfire.libsuperuser.Shell.C1422SH;

/* renamed from: eu.chainfire.libsuperuser.Toolbox */
public class Toolbox {
    private static final int TOYBOX_SDK = 23;
    private static final Object synchronizer = new Object();
    private static volatile String toybox;

    public static void init() {
        if (toybox == null) {
            if (VERSION.SDK_INT < 23) {
                toybox = "";
            } else if (!Debug.getSanityChecksEnabledEffective() || !Debug.onMainThread()) {
                synchronized (synchronizer) {
                    toybox = "";
                    List<String> run = C1422SH.run("toybox");
                    if (run != null) {
                        toybox = " ";
                        for (String str : run) {
                            StringBuilder sb = new StringBuilder();
                            sb.append(toybox);
                            sb.append(str.trim());
                            sb.append(" ");
                            toybox = sb.toString();
                        }
                    }
                }
            } else {
                Debug.log(ShellOnMainThreadException.EXCEPTION_TOOLBOX);
                throw new ShellOnMainThreadException(ShellOnMainThreadException.EXCEPTION_TOOLBOX);
            }
        }
    }

    public static String command(String str, Object... objArr) {
        if (VERSION.SDK_INT < 23) {
            Locale locale = Locale.ENGLISH;
            StringBuilder sb = new StringBuilder();
            sb.append("toolbox ");
            sb.append(str);
            return String.format(locale, sb.toString(), objArr);
        }
        if (toybox == null) {
            init();
        }
        String trim = str.trim();
        int indexOf = trim.indexOf(32);
        String substring = indexOf >= 0 ? trim.substring(0, indexOf) : trim;
        String str2 = toybox;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(" ");
        sb2.append(substring);
        sb2.append(" ");
        if (str2.contains(sb2.toString())) {
            Locale locale2 = Locale.ENGLISH;
            StringBuilder sb3 = new StringBuilder();
            sb3.append("toybox ");
            sb3.append(trim);
            return String.format(locale2, sb3.toString(), objArr);
        }
        Locale locale3 = Locale.ENGLISH;
        StringBuilder sb4 = new StringBuilder();
        sb4.append("toolbox ");
        sb4.append(trim);
        return String.format(locale3, sb4.toString(), objArr);
    }
}
