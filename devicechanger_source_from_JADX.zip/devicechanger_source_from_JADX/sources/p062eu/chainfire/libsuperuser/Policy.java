package p062eu.chainfire.libsuperuser;

import java.util.Iterator;
import java.util.List;
import p062eu.chainfire.libsuperuser.Shell.C1423SU;
import p062eu.chainfire.libsuperuser.Shell.Interactive;

/* renamed from: eu.chainfire.libsuperuser.Policy */
public abstract class Policy {
    private static final int MAX_POLICY_LENGTH = 4064;
    private static volatile Boolean canInject = null;
    private static volatile boolean injected = false;
    private static final Object synchronizer = new Object();

    /* access modifiers changed from: protected */
    public abstract String[] getPolicies();

    public static boolean haveInjected() {
        return injected;
    }

    public static void resetInjected() {
        synchronized (synchronizer) {
            injected = false;
        }
    }

    public static boolean canInject() {
        synchronized (synchronizer) {
            if (canInject != null) {
                boolean booleanValue = canInject.booleanValue();
                return booleanValue;
            }
            canInject = Boolean.valueOf(false);
            List run = Shell.run("sh", new String[]{"supolicy"}, null, false);
            if (run != null) {
                Iterator it = run.iterator();
                while (true) {
                    if (it.hasNext()) {
                        if (((String) it.next()).contains("supolicy")) {
                            canInject = Boolean.valueOf(true);
                            break;
                        }
                    } else {
                        break;
                    }
                }
            }
            boolean booleanValue2 = canInject.booleanValue();
            return booleanValue2;
        }
    }

    public static void resetCanInject() {
        synchronized (synchronizer) {
            canInject = null;
        }
    }

    /* access modifiers changed from: protected */
    public List<String> getInjectCommands() {
        return getInjectCommands(true);
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0096, code lost:
        return r1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0098, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.List<java.lang.String> getInjectCommands(boolean r9) {
        /*
            r8 = this;
            java.lang.Object r0 = synchronizer
            monitor-enter(r0)
            boolean r1 = p062eu.chainfire.libsuperuser.Shell.C1423SU.isSELinuxEnforcing()     // Catch:{ all -> 0x0099 }
            r2 = 0
            if (r1 != 0) goto L_0x000c
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            return r2
        L_0x000c:
            if (r9 == 0) goto L_0x0016
            boolean r9 = canInject()     // Catch:{ all -> 0x0099 }
            if (r9 != 0) goto L_0x0016
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            return r2
        L_0x0016:
            boolean r9 = injected     // Catch:{ all -> 0x0099 }
            if (r9 == 0) goto L_0x001c
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            return r2
        L_0x001c:
            java.lang.String[] r9 = r8.getPolicies()     // Catch:{ all -> 0x0099 }
            if (r9 == 0) goto L_0x0097
            int r1 = r9.length     // Catch:{ all -> 0x0099 }
            if (r1 <= 0) goto L_0x0097
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch:{ all -> 0x0099 }
            r1.<init>()     // Catch:{ all -> 0x0099 }
            java.lang.String r2 = ""
            int r3 = r9.length     // Catch:{ all -> 0x0099 }
            r4 = 0
        L_0x002e:
            if (r4 >= r3) goto L_0x007b
            r5 = r9[r4]     // Catch:{ all -> 0x0099 }
            int r6 = r2.length()     // Catch:{ all -> 0x0099 }
            if (r6 == 0) goto L_0x005f
            int r6 = r2.length()     // Catch:{ all -> 0x0099 }
            int r7 = r5.length()     // Catch:{ all -> 0x0099 }
            int r6 = r6 + r7
            int r6 = r6 + 3
            r7 = 4064(0xfe0, float:5.695E-42)
            if (r6 >= r7) goto L_0x0048
            goto L_0x005f
        L_0x0048:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x0099 }
            r5.<init>()     // Catch:{ all -> 0x0099 }
            java.lang.String r6 = "supolicy --live"
            r5.append(r6)     // Catch:{ all -> 0x0099 }
            r5.append(r2)     // Catch:{ all -> 0x0099 }
            java.lang.String r2 = r5.toString()     // Catch:{ all -> 0x0099 }
            r1.add(r2)     // Catch:{ all -> 0x0099 }
            java.lang.String r2 = ""
            goto L_0x0078
        L_0x005f:
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ all -> 0x0099 }
            r6.<init>()     // Catch:{ all -> 0x0099 }
            r6.append(r2)     // Catch:{ all -> 0x0099 }
            java.lang.String r2 = " \""
            r6.append(r2)     // Catch:{ all -> 0x0099 }
            r6.append(r5)     // Catch:{ all -> 0x0099 }
            java.lang.String r2 = "\""
            r6.append(r2)     // Catch:{ all -> 0x0099 }
            java.lang.String r2 = r6.toString()     // Catch:{ all -> 0x0099 }
        L_0x0078:
            int r4 = r4 + 1
            goto L_0x002e
        L_0x007b:
            int r9 = r2.length()     // Catch:{ all -> 0x0099 }
            if (r9 <= 0) goto L_0x0095
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ all -> 0x0099 }
            r9.<init>()     // Catch:{ all -> 0x0099 }
            java.lang.String r3 = "supolicy --live"
            r9.append(r3)     // Catch:{ all -> 0x0099 }
            r9.append(r2)     // Catch:{ all -> 0x0099 }
            java.lang.String r9 = r9.toString()     // Catch:{ all -> 0x0099 }
            r1.add(r9)     // Catch:{ all -> 0x0099 }
        L_0x0095:
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            return r1
        L_0x0097:
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            return r2
        L_0x0099:
            r9 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: p062eu.chainfire.libsuperuser.Policy.getInjectCommands(boolean):java.util.List");
    }

    public void inject() {
        synchronized (synchronizer) {
            List injectCommands = getInjectCommands();
            if (injectCommands != null && injectCommands.size() > 0) {
                C1423SU.run(injectCommands);
            }
            injected = true;
        }
    }

    public void inject(Interactive interactive, boolean z) {
        synchronized (synchronizer) {
            List injectCommands = getInjectCommands(z);
            if (injectCommands != null && injectCommands.size() > 0) {
                interactive.addCommand(injectCommands);
                if (z) {
                    interactive.waitForIdle();
                }
            }
            injected = true;
        }
    }
}
