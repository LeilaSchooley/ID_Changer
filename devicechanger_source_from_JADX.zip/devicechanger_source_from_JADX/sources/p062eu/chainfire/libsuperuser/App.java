package p062eu.chainfire.libsuperuser;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.widget.Toast;

/* renamed from: eu.chainfire.libsuperuser.App */
public class App extends Application {
    private static Handler mApplicationHandler = new Handler();

    public static void toast(final Context context, final String str) {
        if (context != null) {
            if (!(context instanceof App)) {
                context = context.getApplicationContext();
            }
            if (context instanceof App) {
                ((App) context).runInApplicationThread(new Runnable() {
                    public void run() {
                        Toast.makeText(context, str, 1).show();
                    }
                });
            }
        }
    }

    public void runInApplicationThread(Runnable runnable) {
        mApplicationHandler.post(runnable);
    }

    public void onCreate() {
        super.onCreate();
        try {
            Class.forName("android.os.AsyncTask");
        } catch (ClassNotFoundException unused) {
        }
    }
}
