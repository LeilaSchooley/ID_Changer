package p062eu.chainfire.libsuperuser;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

/* renamed from: eu.chainfire.libsuperuser.StreamGobbler */
public class StreamGobbler extends Thread {
    private OnLineListener listener = null;
    private BufferedReader reader = null;
    private String shell = null;
    private List<String> writer = null;

    /* renamed from: eu.chainfire.libsuperuser.StreamGobbler$OnLineListener */
    public interface OnLineListener {
        void onLine(String str);
    }

    public StreamGobbler(String str, InputStream inputStream, List<String> list) {
        this.shell = str;
        this.reader = new BufferedReader(new InputStreamReader(inputStream));
        this.writer = list;
    }

    public StreamGobbler(String str, InputStream inputStream, OnLineListener onLineListener) {
        this.shell = str;
        this.reader = new BufferedReader(new InputStreamReader(inputStream));
        this.listener = onLineListener;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:9|10|15) */
    /* JADX WARNING: Code restructure failed: missing block: B:16:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x002f */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x002f A[SYNTHETIC, Splitter:B:9:0x002f] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r5 = this;
        L_0x0000:
            java.io.BufferedReader r0 = r5.reader     // Catch:{ IOException -> 0x002f }
            java.lang.String r0 = r0.readLine()     // Catch:{ IOException -> 0x002f }
            if (r0 == 0) goto L_0x002f
            java.lang.String r1 = "[%s] %s"
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ IOException -> 0x002f }
            r3 = 0
            java.lang.String r4 = r5.shell     // Catch:{ IOException -> 0x002f }
            r2[r3] = r4     // Catch:{ IOException -> 0x002f }
            r3 = 1
            r2[r3] = r0     // Catch:{ IOException -> 0x002f }
            java.lang.String r1 = java.lang.String.format(r1, r2)     // Catch:{ IOException -> 0x002f }
            p062eu.chainfire.libsuperuser.Debug.logOutput(r1)     // Catch:{ IOException -> 0x002f }
            java.util.List<java.lang.String> r1 = r5.writer     // Catch:{ IOException -> 0x002f }
            if (r1 == 0) goto L_0x0025
            java.util.List<java.lang.String> r1 = r5.writer     // Catch:{ IOException -> 0x002f }
            r1.add(r0)     // Catch:{ IOException -> 0x002f }
        L_0x0025:
            eu.chainfire.libsuperuser.StreamGobbler$OnLineListener r1 = r5.listener     // Catch:{ IOException -> 0x002f }
            if (r1 == 0) goto L_0x0000
            eu.chainfire.libsuperuser.StreamGobbler$OnLineListener r1 = r5.listener     // Catch:{ IOException -> 0x002f }
            r1.onLine(r0)     // Catch:{ IOException -> 0x002f }
            goto L_0x0000
        L_0x002f:
            java.io.BufferedReader r0 = r5.reader     // Catch:{ IOException -> 0x0034 }
            r0.close()     // Catch:{ IOException -> 0x0034 }
        L_0x0034:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p062eu.chainfire.libsuperuser.StreamGobbler.run():void");
    }
}
