package p062eu.chainfire.libsuperuser;

import android.os.Looper;
import android.util.Log;

/* renamed from: eu.chainfire.libsuperuser.Debug */
public class Debug {
    public static final int LOG_ALL = 65535;
    public static final int LOG_COMMAND = 2;
    public static final int LOG_GENERAL = 1;
    public static final int LOG_NONE = 0;
    public static final int LOG_OUTPUT = 4;
    public static final String TAG = "libsuperuser";
    private static boolean debug = false;
    private static OnLogListener logListener = null;
    private static int logTypes = 65535;
    private static boolean sanityChecks = true;

    /* renamed from: eu.chainfire.libsuperuser.Debug$OnLogListener */
    public interface OnLogListener {
        void onLog(int i, String str, String str2);
    }

    public static void setDebug(boolean z) {
        debug = z;
    }

    public static boolean getDebug() {
        return debug;
    }

    private static void logCommon(int i, String str, String str2) {
        if (debug && (logTypes & i) == i) {
            if (logListener != null) {
                logListener.onLog(i, str, str2);
                return;
            }
            String str3 = TAG;
            StringBuilder sb = new StringBuilder();
            sb.append("[libsuperuser][");
            sb.append(str);
            sb.append("]");
            sb.append((str2.startsWith("[") || str2.startsWith(" ")) ? "" : " ");
            sb.append(str2);
            Log.d(str3, sb.toString());
        }
    }

    public static void log(String str) {
        logCommon(1, "G", str);
    }

    public static void logCommand(String str) {
        logCommon(2, "C", str);
    }

    public static void logOutput(String str) {
        logCommon(4, "O", str);
    }

    public static void setLogTypeEnabled(int i, boolean z) {
        if (z) {
            logTypes = i | logTypes;
            return;
        }
        logTypes = (i ^ -1) & logTypes;
    }

    public static boolean getLogTypeEnabled(int i) {
        return (logTypes & i) == i;
    }

    public static boolean getLogTypeEnabledEffective(int i) {
        return getDebug() && getLogTypeEnabled(i);
    }

    public static void setOnLogListener(OnLogListener onLogListener) {
        logListener = onLogListener;
    }

    public static OnLogListener getOnLogListener() {
        return logListener;
    }

    public static void setSanityChecksEnabled(boolean z) {
        sanityChecks = z;
    }

    public static boolean getSanityChecksEnabled() {
        return sanityChecks;
    }

    public static boolean getSanityChecksEnabledEffective() {
        return getDebug() && getSanityChecksEnabled();
    }

    public static boolean onMainThread() {
        return Looper.myLooper() != null && Looper.myLooper() == Looper.getMainLooper();
    }
}
