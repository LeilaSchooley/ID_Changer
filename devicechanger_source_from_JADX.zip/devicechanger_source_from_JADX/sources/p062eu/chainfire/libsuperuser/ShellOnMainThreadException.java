package p062eu.chainfire.libsuperuser;

/* renamed from: eu.chainfire.libsuperuser.ShellOnMainThreadException */
public class ShellOnMainThreadException extends RuntimeException {
    public static final String EXCEPTION_COMMAND = "App attempted to run a shell command from the main thread";
    public static final String EXCEPTION_NOT_IDLE = "App attempted to wait for a non-idle shell to close on the main thread";
    public static final String EXCEPTION_TOOLBOX = "App attempted to init the Toolbox class from the main thread";
    public static final String EXCEPTION_WAIT_IDLE = "App attempted to wait for a shell to become idle on the main thread";

    public ShellOnMainThreadException(String str) {
        super(str);
    }
}
